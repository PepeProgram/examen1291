from setuptools import setup

setup(
    name='Juego Pygame',
    version='1.0.0',
    url='www.unacualquiera.com',
    license='SOLO PARA MI',
    author='yO',
    author_email='elmio@pepe.es',
    description='Ejercicio examen',
    install_requires=open('requirements.txt').readlines(),
)
